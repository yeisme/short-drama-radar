import { asJudgmentError, JudgmentError, ValidationError } from "./errors.ts";
import type { Capabilities, PrecisionPolicy, Request, Result } from "./types.ts";
import { defaultPrecisionPolicy } from "./types.ts";
import { checkCapabilities, parseRequestTree, parseResultTree, type GateOptions, type RequestOptions } from "./validate.ts";
import type { CancelingTransport, ReconcilingTransport, Transport } from "./transport.ts";

export interface ClientOptions {
  knownExtensions?: readonly string[];
  precisionPolicy?: PrecisionPolicy;
  gateOptions?: GateOptions;
  staticCapabilities?: Capabilities;
}

function asValidationError(err: unknown): ValidationError | null {
  return err instanceof ValidationError ? err : null;
}

/**
 * SDK facade. It never retries: one evaluate maps to exactly one transport
 * call, and post-submit uncertainty is surfaced as outcome_unknown /
 * reconcile_first for the caller to decide.
 */
export class JudgmentClient {
  private readonly transport: Transport;
  private readonly options: ClientOptions;
  private caps: Capabilities | null = null;

  constructor(transport: Transport, options: ClientOptions = {}) {
    this.transport = transport;
    this.options = options;
  }

  getTransport(): Transport {
    return this.transport;
  }

  /** Negotiated capabilities; discovered once unless statically configured. */
  async capabilities(signal?: AbortSignal): Promise<Capabilities> {
    if (this.caps) return this.caps;
    if (this.options.staticCapabilities) {
      this.caps = this.options.staticCapabilities;
      return this.caps;
    }
    if (signal?.aborted) {
      throw new JudgmentError("deadline_exceeded", "not_submitted", "safe_before_submit", "", "aborted_before_dispatch");
    }
    try {
      const caps = await this.transport.capabilities(signal);
      if (!caps) {
        throw new JudgmentError("invalid_response", "not_submitted", "never", "", "capabilities_invalid");
      }
      this.caps = caps;
      return this.caps;
    } catch (err) {
      throw asJudgmentError(err, "capabilities_discovery_failed");
    }
  }

  /**
   * One explicitly bounded attempt: local validation, capability gate, then
   * exactly one transport call and strict result validation. The request
   * deadline (limits.deadline_ms) is enforced locally with an AbortController
   * chained onto the caller's signal; a post-dispatch abort is classified as
   * outcome_unknown, never as a silent retry.
   */
  async evaluate(req: Request, signal?: AbortSignal): Promise<Result> {
    if (!req) {
      throw new JudgmentError("invalid_request", "not_submitted", "safe_before_submit", "", "request_not_parsed");
    }
    const requestOptions: RequestOptions = { knownExtensions: this.options.knownExtensions };
    const requestError = asValidationError(
      (() => {
        try {
          parseRequestTree(req.wire, requestOptions); // strict re-validation
          return null;
        } catch (err) {
          return err;
        }
      })(),
    );
    if (requestError) throw requestError.asRequestError();

    const caps = await this.capabilities(signal);
    const gateError = asValidationError(
      (() => {
        try {
          checkCapabilities(caps, req, this.options.gateOptions ?? {});
          return null;
        } catch (err) {
          return err;
        }
      })(),
    );
    if (gateError) throw gateError.asCapabilityError();

    const own = new AbortController();
    const deadlineMs = req.limits?.deadlineMs ?? null;
    const timer = deadlineMs !== null ? setTimeout(() => own.abort("deadline"), deadlineMs) : null;
    const forwardAbort = () => own.abort("caller");
    signal?.addEventListener("abort", forwardAbort);
    let raw: Result;
    try {
      if (own.signal.aborted) {
        throw new JudgmentError("deadline_exceeded", "not_submitted", "safe_before_submit", "", "aborted_before_dispatch");
      }
      raw = await this.transport.evaluate(req, own.signal);
    } catch (err) {
      // After the request left the caller's hands the outcome cannot be
      // proven un-submitted; classify as unknown, never auto-resend.
      throw asJudgmentError(err, "evaluate_failed");
    } finally {
      if (timer !== null) clearTimeout(timer);
      signal?.removeEventListener("abort", forwardAbort);
    }
    const policy = this.options.precisionPolicy ?? defaultPrecisionPolicy();
    try {
      return parseResultTree(raw.wire, req, policy);
    } catch (err) {
      const ve = asValidationError(err);
      if (ve) throw ve.asResponseError();
      throw asJudgmentError(err, "result_validation_failed");
    }
  }

  /** Query an existing attempt; only when declared and implemented. */
  async reconcile(attemptId: string, signal?: AbortSignal): Promise<Result> {
    const caps = await this.capabilities(signal);
    if (!caps.supportsReconcile) {
      throw new JudgmentError("unsupported_capability", "not_submitted", "never", "", "reconcile_not_supported");
    }
    const rt = this.transport as Partial<ReconcilingTransport>;
    if (typeof rt.reconcile !== "function") {
      throw new JudgmentError("unsupported_capability", "not_submitted", "never", "", "transport_cannot_reconcile");
    }
    try {
      return await rt.reconcile(attemptId, signal);
    } catch (err) {
      throw asJudgmentError(err, "reconcile_failed");
    }
  }

  /** Request a declared remote cancel; never implies billing stopped. */
  async cancel(attemptId: string, signal?: AbortSignal): Promise<void> {
    const caps = await this.capabilities(signal);
    if (!caps.supportsCancel) {
      throw new JudgmentError("unsupported_capability", "not_submitted", "never", "", "cancel_not_supported");
    }
    const ct = this.transport as Partial<CancelingTransport>;
    if (typeof ct.cancel !== "function") {
      throw new JudgmentError("unsupported_capability", "not_submitted", "never", "", "transport_cannot_cancel");
    }
    try {
      await ct.cancel(attemptId, signal);
    } catch (err) {
      throw asJudgmentError(err, "cancel_failed");
    }
  }
}
