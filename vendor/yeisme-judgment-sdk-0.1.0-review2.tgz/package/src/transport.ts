import { JudgmentError } from "./errors.ts";
import type { Capabilities, Request, Result } from "./types.ts";

/**
 * Injected execution boundary. Implementations own network access and
 * credentials; the SDK itself holds none. Rejected errors are either
 * JudgmentError (already classified) or raw infrastructure errors; the
 * client maps raw post-dispatch failures to outcome_unknown.
 */
export interface Transport {
  capabilities(signal?: AbortSignal): Promise<Capabilities>;
  evaluate(req: Request, signal?: AbortSignal): Promise<Result>;
}

/** Optional extension: query an existing attempt without resubmitting. */
export interface ReconcilingTransport extends Transport {
  reconcile(attemptId: string, signal?: AbortSignal): Promise<Result>;
}

/**
 * Optional extension: request a declared remote cancel. A local Abort never
 * implies the provider stopped or that billing ceased.
 */
export interface CancelingTransport extends Transport {
  cancel(attemptId: string, signal?: AbortSignal): Promise<void>;
}

/**
 * In-memory transport for offline consumers and conformance runs: no
 * network, no credentials, deterministic scripting. Counters prove call
 * counts (for example: zero provider calls on replay).
 */
export class FixtureTransport implements Transport {
  readonly caps: Capabilities;
  evaluateFn: (req: Request, signal?: AbortSignal) => Promise<Result>;
  capabilitiesFn: ((signal?: AbortSignal) => Promise<Capabilities>) | undefined;
  capabilitiesCalls = 0;
  evaluateCalls = 0;

  constructor(caps: Capabilities, fn: (req: Request, signal?: AbortSignal) => Promise<Result>) {
    this.caps = caps;
    this.evaluateFn = fn;
  }

  capabilities(signal?: AbortSignal): Promise<Capabilities> {
    this.capabilitiesCalls++;
    if (this.capabilitiesFn) return this.capabilitiesFn(signal);
    return Promise.resolve(this.caps);
  }

  evaluate(req: Request, signal?: AbortSignal): Promise<Result> {
    this.evaluateCalls++;
    if (!this.evaluateFn) {
      return Promise.reject(
        new JudgmentError("unavailable", "not_submitted", "safe_before_submit", "", "fixture_not_scripted"),
      );
    }
    return this.evaluateFn(req, signal);
  }
}
