import type { Tree } from "./canonical.ts";

/** Primitives supported by contract version 1.0. */
export type Primitive = "choice" | "ordinal_score" | "binary";

export type PinLevel = "router_model_id" | "provider_exact_model" | "underlying_revision";

export type ExecutionStatus = "succeeded" | "partial" | "failed" | "unknown";

export type AnswerStatus = "answered" | "abstained" | "error";

export type ConfidenceProvenance = "provider_self_report" | "calibrated" | "derived";

export interface Scope {
  readonly ownerId: string | null;
  readonly projectId: string | null;
  readonly principalId: string | null;
  readonly subject: string | null;
}

/**
 * Transport/route identity, upstream reported identity, and immutable
 * underlying revision stay distinct; unknown revision stays null with
 * underlyingRevisionVerified false and a router ID is never rewritten into a
 * direct-provider exact model.
 */
export interface ModelIdentity {
  readonly transportProvider: string;
  readonly modelProvider: string | null;
  readonly requestedModel: string;
  readonly responseModel: string | null;
  readonly underlyingRevision: string | null;
  readonly pinLevel: PinLevel;
  readonly underlyingRevisionVerified: boolean;
}

export interface VersionedRef {
  readonly id: string;
  readonly version: string;
  readonly digest: string;
}

/** Untrusted bounded inline material plus provenance. */
export interface Source {
  readonly sourceId: string;
  readonly revision: string;
  readonly digest: string;
  readonly inlineText: string | null;
  readonly language: string | null;
  readonly localRef: string | null;
}

export interface SourceBinding {
  readonly sourceId: string;
}

export interface Candidate {
  readonly candidateId: string;
  readonly sourceBindings: readonly SourceBinding[];
}

export interface ChoiceOption {
  readonly optionId: string;
  readonly label: string;
}

export interface OrdinalLevel {
  readonly levelId: string;
  readonly numericValue: number;
  readonly label: string;
}

export interface Question {
  readonly questionId: string;
  readonly primitive: Primitive;
  readonly prompt: string;
  readonly candidateIds: readonly string[];
  readonly required: boolean;
  readonly choiceOptions: readonly ChoiceOption[] | null;
  readonly ordinalLevels: readonly OrdinalLevel[] | null;
}

export interface Limits {
  readonly deadlineMs: number | null;
  readonly maxCandidates: number | null;
  readonly maxQuestions: number | null;
  readonly maxInputBytes: number | null;
  readonly maxOutputBytes: number | null;
}

export interface Extension {
  readonly name: string;
  readonly required: boolean;
  readonly payload: Readonly<Record<string, unknown>>;
}

export interface Request {
  readonly requestId: string;
  readonly attemptId: string;
  readonly scope: Scope;
  readonly model: ModelIdentity;
  readonly questionSet: VersionedRef;
  readonly policyRef: VersionedRef;
  readonly sources: readonly Source[];
  readonly candidates: readonly Candidate[];
  readonly questions: readonly Question[];
  readonly limits: Limits | null;
  readonly extensions: readonly Extension[];
  /** Retained wire tree; binds the input digest. */
  readonly wire: Tree;

  inputDigest(): string;
  expectedPairs(): Array<[string, string]>;
  wireJson(): string;
}

export interface Adapter {
  readonly name: string;
  readonly version: string;
}

export interface DistributionTolerance {
  readonly version: string;
  readonly absSumTolerance: number;
}

export interface Capabilities {
  readonly contractVersion: string;
  readonly adapter: Adapter;
  readonly model: ModelIdentity;
  readonly modalities: readonly string[];
  readonly primitives: readonly Primitive[];
  readonly maxCandidates: number;
  readonly maxQuestions: number;
  readonly maxSources: number;
  readonly maxInlineTextBytes: number;
  readonly languages: readonly string[];
  readonly probabilityAvailable: boolean;
  readonly confidenceAvailable: boolean;
  readonly confidenceProvenance: ConfidenceProvenance | null;
  readonly distributionTolerance: DistributionTolerance;
  readonly supportsIdempotency: boolean;
  readonly supportsReconcile: boolean;
  readonly supportsCancel: boolean;
  readonly extensions: readonly string[];
}

export interface Confidence {
  readonly value: number;
  readonly provenance: ConfidenceProvenance;
}

export interface Normalization {
  readonly version: string;
  readonly rule: string;
}

export interface AnswerValue {
  readonly optionId?: string;
  readonly levelId?: string;
  readonly binary?: boolean;
}

export interface Usage {
  readonly inputTokens: number | null;
  readonly outputTokens: number | null;
  readonly cost: number | null;
}

export interface SourceRef {
  readonly sourceId: string;
  readonly revision: string;
}

export interface Item {
  readonly candidateId: string;
  readonly questionId: string;
  readonly answerStatus: AnswerStatus;
  readonly value: AnswerValue | null;
  readonly distribution: Readonly<Record<string, number>> | null;
  readonly confidence: Confidence | null;
  readonly probabilityTrue: number | null;
  readonly reasonCode: string | null;
  readonly sourceRefs: readonly SourceRef[];
  readonly providerValue: Readonly<Record<string, unknown>> | null;
  readonly derivedValue: Readonly<Record<string, unknown>> | null;
  readonly normalization: Normalization | null;
}

export interface Result {
  readonly requestId: string;
  readonly attemptId: string;
  readonly inputDigest: string;
  readonly executionStatus: ExecutionStatus;
  readonly resolvedModel: ModelIdentity;
  readonly items: readonly Item[];
  readonly usage: Usage | null;
  readonly latencyMs: number | null;
  readonly providerRequestId: string | null;
  readonly extensions: Readonly<Record<string, unknown>>;
  /** Retained wire tree for evidence persistence. */
  readonly wire: Tree;

  itemByPair(candidateId: string, questionId: string): Item | null;
  wireJson(): string;
}

/** Versioned precision policy applied to distribution sums. */
export interface PrecisionPolicy {
  readonly version: string;
  readonly absSumTolerance: number;
}

export function defaultPrecisionPolicy(): PrecisionPolicy {
  return { version: "yeisme.judgment.precision.v1", absSumTolerance: 1e-6 };
}
