import type { Request, Result } from "./types.ts";

export interface AdoptionBlocker {
  readonly candidateId: string;
  readonly questionId: string;
  readonly answerStatus: string | null;
  /** missing | abstained | error */
  readonly problem: string;
}

/**
 * Lists every required question pair that is not explicitly answered. Any
 * non-empty list means the owner must not present the result as a complete,
 * adoptable evaluation; structure is validated before this runs, and domain
 * thresholds stay with the owner.
 */
export function adoptionBlockers(req: Request, res: Result): AdoptionBlocker[] {
  if (!req || !res) return [];
  const blockers: AdoptionBlocker[] = [];
  for (const question of req.questions) {
    if (!question.required) continue;
    for (const candidateId of question.candidateIds) {
      const item = res.itemByPair(candidateId, question.questionId);
      if (item === null) {
        blockers.push({
          candidateId,
          questionId: question.questionId,
          answerStatus: null,
          problem: "missing",
        });
        continue;
      }
      if (item.answerStatus !== "answered") {
        blockers.push({
          candidateId,
          questionId: question.questionId,
          answerStatus: item.answerStatus,
          problem: item.answerStatus,
        });
      }
    }
  }
  return blockers;
}

/** Whether every required pair is explicitly answered (no domain thresholds). */
export function completeAdoptionAllowed(req: Request, res: Result): boolean {
  return adoptionBlockers(req, res).length === 0;
}
