/**
 * Provider-neutral structured judgment SDK (TypeScript).
 *
 * Contract owner: openspec/changes/aigora-structured-judgment-sdk-v1
 * (Aigora). Wire format: snake_case UTF-8 JSON, schema_version "1.0".
 *
 * The package never reads credentials or the environment, never starts the
 * Aigora gateway, never retries: one evaluate call maps to exactly one
 * transport call, and post-submit uncertainty is reported as
 * outcome_unknown with retry_class reconcile_first.
 */
export { canonicalJson, digest, marshalTree, parseTree, type Tree } from "./canonical.ts";
export {
  ERROR_CODES,
  JudgmentError,
  RETRY_CLASSES,
  SUBMISSION_STATES,
  ValidationError,
  asJudgmentError,
  type ErrorCode,
  type RetryClass,
  type SubmissionState,
} from "./errors.ts";
export {
  adoptionBlockers,
  completeAdoptionAllowed,
  type AdoptionBlocker,
} from "./adoption.ts";
export { FixtureTransport, type CancelingTransport, type ReconcilingTransport, type Transport } from "./transport.ts";
export { JudgmentClient, type ClientOptions } from "./client.ts";
export {
  checkCapabilities,
  parseCapabilities,
  parseCapabilitiesTree,
  parseRequest,
  parseRequestTree,
  parseResult,
  parseResultTree,
  type GateOptions,
  type RequestOptions,
} from "./validate.ts";
export { defaultPrecisionPolicy } from "./types.ts";
export type {
  Adapter,
  AnswerStatus,
  AnswerValue,
  Capabilities,
  Candidate,
  ChoiceOption,
  Confidence,
  ConfidenceProvenance,
  DistributionTolerance,
  ExecutionStatus,
  Extension,
  Item,
  Limits,
  ModelIdentity,
  Normalization,
  OrdinalLevel,
  PinLevel,
  PrecisionPolicy,
  Primitive,
  Question,
  Request,
  Result,
  Scope,
  Source,
  SourceBinding,
  SourceRef,
  Usage,
  VersionedRef,
} from "./types.ts";

export { HttpTransport, type HttpTransportOptions } from "./http.ts";
export { StdioTransport, type StdioTransportOptions } from "./stdio.ts";
