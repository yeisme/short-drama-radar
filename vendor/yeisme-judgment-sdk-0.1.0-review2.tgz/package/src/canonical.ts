import { createHash } from "node:crypto";

/**
 * Canonical JSON (RFC 8785 / JCS equivalent rules): object keys sorted by
 * UTF-16 code unit order, minimal string escaping, ECMAScript number
 * formatting, no NaN/Infinity, no insignificant whitespace. Object key
 * iteration order never influences the output.
 */
export type Tree = null | boolean | string | number | Tree[] | { [key: string]: Tree };

export function canonicalJson(value: Tree): string {
  return writeCanonical(value);
}

function writeCanonical(value: Tree): string {
  if (value === null) return "null";
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error("nonfinite_number");
    return String(value);
  }
  if (Array.isArray(value)) {
    return "[" + value.map((item) => writeCanonical(item)).join(",") + "]";
  }
  const keys = Object.keys(value).sort();
  const parts: string[] = [];
  for (const key of keys) {
    parts.push(JSON.stringify(key) + ":" + writeCanonical(value[key]!));
  }
  return "{" + parts.join(",") + "}";
}

/** Digest of the canonical JSON: "sha256:<64 lowercase hex>". */
export function digest(value: Tree): string {
  return "sha256:" + createHash("sha256").update(canonicalJson(value), "utf8").digest("hex");
}

/** Parse JSON text into a finite-only tree; rejects NaN/Infinity eagerly. */
export function parseTree(text: string): Tree {
  const parsed: unknown = JSON.parse(text, (_key, raw: unknown) => {
    if (typeof raw === "number" && !Number.isFinite(raw)) {
      throw new Error("nonfinite_number");
    }
    return raw;
  });
  assertFinite(parsed);
  return parsed as Tree;
}

function assertFinite(value: unknown): void {
  if (typeof value === "number" && !Number.isFinite(value)) {
    throw new Error("nonfinite_number");
  }
  if (Array.isArray(value)) {
    for (const item of value) assertFinite(item);
    return;
  }
  if (value !== null && typeof value === "object") {
    for (const key of Object.keys(value as Record<string, unknown>)) {
      assertFinite((value as Record<string, unknown>)[key]);
    }
  }
}

/** Plain (non-canonical) JSON text of a tree; used to feed parsers. */
export function marshalTree(value: Tree): string {
  return JSON.stringify(value);
}
