/** Stable error codes of the structured judgment contract. */
export const ERROR_CODES = [
  "unsupported_capability",
  "invalid_request",
  "unauthorized",
  "rate_limited",
  "unavailable",
  "deadline_exceeded",
  "invalid_response",
  "outcome_unknown",
] as const;
export type ErrorCode = (typeof ERROR_CODES)[number];

export const SUBMISSION_STATES = ["not_submitted", "submitted", "unknown"] as const;
export type SubmissionState = (typeof SUBMISSION_STATES)[number];

export const RETRY_CLASSES = ["safe_before_submit", "reconcile_first", "never"] as const;
export type RetryClass = (typeof RETRY_CLASSES)[number];

/**
 * Structured, redacted error envelope. diagnosticRef may carry an opaque
 * reference; detail carries only bounded reason tokens, never provider
 * bodies or raw payloads.
 */
export class JudgmentError extends Error {
  readonly code: ErrorCode;
  readonly submissionState: SubmissionState;
  readonly retryClass: RetryClass;
  readonly diagnosticRef: string;
  readonly detail: string;

  constructor(
    code: ErrorCode,
    submissionState: SubmissionState,
    retryClass: RetryClass,
    diagnosticRef: string,
    detail: string,
  ) {
    super(`judgment: ${code} (submission_state=${submissionState} retry_class=${retryClass}): ${detail}`);
    this.name = "JudgmentError";
    this.code = code;
    this.submissionState = submissionState;
    this.retryClass = retryClass;
    this.diagnosticRef = diagnosticRef;
    this.detail = detail;
  }
}

/**
 * Local contract violation with a stable reason token shared with the Go
 * implementation and the conformance vectors.
 */
export class ValidationError extends Error {
  readonly reason: string;
  readonly detail: string;

  constructor(reason: string, detail: string) {
    super(`judgment: validation failed: ${reason}: ${detail}`);
    this.name = "ValidationError";
    this.reason = reason;
    this.detail = detail;
  }

  /** Request rejected before anything was submitted. */
  asRequestError(): JudgmentError {
    return new JudgmentError("invalid_request", "not_submitted", "safe_before_submit", "", this.reason);
  }

  /** Unusable response: the attempt did reach the executor; reconcile first. */
  asResponseError(): JudgmentError {
    return new JudgmentError("invalid_response", "submitted", "reconcile_first", "", this.reason);
  }

  /** Capability gate refusal. */
  asCapabilityError(): JudgmentError {
    return new JudgmentError("unsupported_capability", "not_submitted", "never", "", this.reason);
  }
}

/** Convert any thrown value into a fail-closed JudgmentError. */
export function asJudgmentError(err: unknown, detail: string): JudgmentError {
  if (err instanceof JudgmentError) return err;
  return new JudgmentError("outcome_unknown", "unknown", "reconcile_first", "", detail);
}
