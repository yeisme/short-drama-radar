import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { JudgmentError, type ErrorCode, type SubmissionState, type RetryClass } from "./errors.ts";
import type { Capabilities, Request, Result } from "./types.ts";
import { defaultPrecisionPolicy } from "./types.ts";
import { parseCapabilities, parseResult } from "./validate.ts";
import type { Transport } from "./transport.ts";

export interface StdioTransportOptions {
  /**
   * Explicit executable argv. There is no shell interpolation and no
   * implicit discovery: callers must configure the executable path
   * deliberately. Production integrations use the typed HTTP transport.
   */
  argv: readonly string[];
  /** Bound for the single protocol frame (default 4 MiB). */
  maxLineBytes?: number;
  cwd?: string;
  env?: Readonly<Record<string, string>>;
}

const DEFAULT_MAX_LINE = 4 << 20;

/**
 * Optional local stdio transport: one JSON request/response exchange with a
 * version handshake. stdout carries protocol only; stderr is captured but
 * never surfaced — only a redacted digest reference survives.
 */
export class StdioTransport implements Transport {
  private readonly options: Required<Pick<StdioTransportOptions, "maxLineBytes">> & StdioTransportOptions;

  constructor(opts: StdioTransportOptions) {
    if (!opts.argv || opts.argv.length === 0 || !opts.argv[0]?.trim()) {
      throw new Error("judgment: stdio transport requires an explicit argv");
    }
    this.options = { ...opts, maxLineBytes: opts.maxLineBytes ?? DEFAULT_MAX_LINE };
  }

  async capabilities(signal?: AbortSignal): Promise<Capabilities> {
    const payload = await this.exchange("capabilities", {}, signal);
    try {
      return parseCapabilities(JSON.stringify(payload));
    } catch (err) {
      if ((err as { name?: string }).name === "ValidationError") {
        throw new JudgmentError(
          "invalid_response", "not_submitted", "safe_before_submit", "",
          (err as { reason: string }).reason,
        );
      }
      throw new JudgmentError("invalid_response", "not_submitted", "safe_before_submit", "", "capabilities_parse_failed");
    }
  }

  async evaluate(req: Request, signal?: AbortSignal): Promise<Result> {
    const payload = await this.exchange("evaluate", JSON.parse(req.wireJson()), signal);
    try {
      return parseResult(JSON.stringify(payload), req, defaultPrecisionPolicy());
    } catch (err) {
      if ((err as { name?: string }).name === "ValidationError") {
        throw (err as { asResponseError: () => JudgmentError }).asResponseError();
      }
      throw new JudgmentError("invalid_response", "unknown", "reconcile_first", "", "result_parse_failed");
    }
  }

  private exchange(kind: string, payload: unknown, signal?: AbortSignal): Promise<unknown> {
    return new Promise<unknown>((resolve, reject) => {
      const child = spawn(this.options.argv[0]!, this.options.argv.slice(1), {
        cwd: this.options.cwd,
        env: this.options.env ? { ...this.options.env } : undefined,
        stdio: ["pipe", "pipe", "pipe"],
      });
      let settled = false;
      const stderrChunks: Buffer[] = [];
      let stderrTotal = 0;
      const stdoutChunks: Buffer[] = [];
      let stdoutTotal = 0;
      let finished = false;

      const settle = (err: unknown, value?: unknown) => {
        if (settled) return;
        settled = true;
        if (err) reject(err);
        else resolve(value);
      };

      const stderrRef = (): string => {
        const digest = createHash("sha256").update(Buffer.concat(stderrChunks)).digest("hex").slice(0, 12);
        return `stdio-stderr:sha256:${digest}`;
      };

      child.stdout.setEncoding("utf8");
      child.stdout.on("data", (chunk: string) => {
        if (finished) return;
        stdoutTotal += chunk.length;
        if (stdoutTotal > this.options.maxLineBytes) {
          finished = true;
          child.kill();
          settle(new JudgmentError(
            "invalid_response", "unknown", "reconcile_first", stderrRef(), "stdio_frame_oversize",
          ));
          return;
        }
        stdoutChunks.push(Buffer.from(chunk, "utf8"));
        const text = Buffer.concat(stdoutChunks).toString("utf8");
        const newline = text.indexOf("\n");
        if (newline >= 0) {
          finished = true;
          const line = text.slice(0, newline).trim();
          child.stdout.removeAllListeners("data");
          // Extra stdout after the first frame is ignored, never surfaced.
          try {
            const frame = JSON.parse(line) as {
              schema_version?: string;
              ok?: boolean;
              payload?: unknown;
            };
            const major = (frame.schema_version ?? "").split(".")[0];
            if (major !== "1") {
              settle(new JudgmentError(
                "invalid_response", "unknown", "reconcile_first", stderrRef(), "stdio_version_mismatch",
              ));
              child.kill();
              return;
            }
            if (!frame.ok) {
              const envelope = (frame.payload ?? {}) as {
                error?: { code?: string; submission_state?: string; retry_class?: string; diagnostic_ref?: string };
              };
              const e = envelope.error;
              const valid = (list: readonly string[], v: string | undefined): v is string =>
                typeof v === "string" && list.includes(v);
              if (
                e &&
                valid(["unsupported_capability", "invalid_request", "unauthorized", "rate_limited",
                  "unavailable", "deadline_exceeded", "invalid_response", "outcome_unknown"], e.code) &&
                valid(["not_submitted", "submitted", "unknown"], e.submission_state) &&
                valid(["safe_before_submit", "reconcile_first", "never"], e.retry_class)
              ) {
                settle(new JudgmentError(
                  e.code as ErrorCode, e.submission_state as SubmissionState, e.retry_class as RetryClass, e.diagnostic_ref ?? "", "stdio_child_error",
                ));
              } else {
                settle(new JudgmentError(
                  "invalid_response", "unknown", "reconcile_first", stderrRef(), "stdio_error_envelope_invalid",
                ));
              }
              return;
            }
            settle(null, frame.payload);
          } catch {
            settle(new JudgmentError(
              "invalid_response", "unknown", "reconcile_first", stderrRef(), "frame_not_json",
            ));
          }
        }
      });
      child.stderr.setEncoding("utf8");
      child.stderr.on("data", (chunk: string) => {
        // Bounded capture for redacted diagnostics only; never surfaced.
        stderrTotal += chunk.length;
        if (stderrTotal <= 1 << 16) stderrChunks.push(Buffer.from(chunk, "utf8"));
      });
      child.on("error", (err) => {
        settle(new JudgmentError("unavailable", "not_submitted", "safe_before_submit", "", "child_start_failed"), );
        void err;
      });
      child.on("close", () => {
        if (!settled) {
          settle(new JudgmentError(
            "invalid_response", "unknown", "reconcile_first", stderrRef(), "no_protocol_frame",
          ));
        }
      });
      const onAbort = () => {
        child.kill();
        settle(signal?.reason ?? new Error("aborted"));
      };
      signal?.addEventListener("abort", onAbort, { once: true });
      child.stdin.write(JSON.stringify({ schema_version: "1.0", kind, payload }) + "\n");
      child.stdin.end();
    });
  }
}
