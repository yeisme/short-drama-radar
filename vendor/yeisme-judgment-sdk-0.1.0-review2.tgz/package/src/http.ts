import { createHash } from "node:crypto";
import { JudgmentError, ERROR_CODES, SUBMISSION_STATES, RETRY_CLASSES } from "./errors.ts";
import type { Capabilities, Request, Result } from "./types.ts";
import { defaultPrecisionPolicy } from "./types.ts";
import { parseCapabilities, parseResult } from "./validate.ts";
import type { Transport } from "./transport.ts";

export interface HttpTransportOptions {
  /** Adapter base URL, for example "https://adapter.example". */
  baseUrl: string;
  /** Injectable fetch (tests, proxies); defaults to global fetch. */
  fetchImpl?: typeof fetch;
  /** Per-request headers (Authorization injection belongs to the caller). */
  headers?: () => Record<string, string>;
  /** Response body cap in bytes (default 1 MiB). */
  maxOutputBytes?: number;
}

const CAPABILITIES_PATH = "/v1/judgments/capabilities";
const EVALUATE_PATH = "/v1/judgments/evaluate";
const DEFAULT_MAX_OUTPUT = 1 << 20;

/**
 * Typed HTTP transport: GET /v1/judgments/capabilities and
 * POST /v1/judgments/evaluate. Redirects are never followed (Authorization
 * can never be replayed), error bodies are withheld (only classifications
 * and a redacted digest reference survive), and exactly one request is sent
 * per call — no implicit retries.
 */
export class HttpTransport implements Transport {
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly headers?: () => Record<string, string>;
  private readonly maxOutputBytes: number;

  constructor(opts: HttpTransportOptions) {
    let parsed: URL;
    try {
      parsed = new URL(opts.baseUrl);
    } catch {
      throw new Error("judgment: invalid base url");
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      throw new Error("judgment: invalid base url");
    }
    this.baseUrl = parsed.toString().replace(/\/$/, "");
    this.fetchImpl = opts.fetchImpl ?? fetch;
    this.headers = opts.headers;
    this.maxOutputBytes = opts.maxOutputBytes ?? DEFAULT_MAX_OUTPUT;
  }

  async capabilities(signal?: AbortSignal): Promise<Capabilities> {
    const res = await this.send(CAPABILITIES_PATH, "GET", null, signal);
    if (res.status !== 200) {
      throw capabilitiesStatusError(res.status);
    }
    const body = await this.readBounded(res);
    try {
      return parseCapabilities(decodeUtf8(body));
    } catch (err) {
      throw new JudgmentError("invalid_response", "not_submitted", "safe_before_submit", "", "capabilities_parse_failed");
    }
  }

  async evaluate(req: Request, signal?: AbortSignal): Promise<Result> {
    const res = await this.send(EVALUATE_PATH, "POST", req.wireJson(), signal);
    if (res.status !== 200) {
      // Body withheld; a digest reference is derived and discarded content
      // never reaches the caller.
      const body = await this.readBounded(res);
      throw parseHTTPError(body, res.status) ?? classifyStatus(res.status);
    }
    const body = await this.readBounded(res);
    try {
      return parseResult(decodeUtf8(body), req, defaultPrecisionPolicy());
    } catch (err) {
      if ((err as { name?: string }).name === "ValidationError") {
        throw (err as { asResponseError: () => JudgmentError }).asResponseError();
      }
      throw new JudgmentError("invalid_response", "unknown", "reconcile_first", "", "result_parse_failed");
    }
  }

  private async send(
    path: string,
    method: "GET" | "POST",
    body: string | null,
    signal?: AbortSignal,
  ): Promise<Response> {
    const headers: Record<string, string> = { Accept: "application/json" };
    if (body !== null) headers["Content-Type"] = "application/json";
    for (const [k, v] of Object.entries(this.headers?.() ?? {})) headers[k] = v;
    let res: Response;
    try {
      res = await this.fetchImpl(this.baseUrl + path, {
        method,
        headers,
        body,
        signal,
        redirect: "manual",
      });
    } catch (err) {
      // Network-layer failures propagate raw: the client fail-closes to
      // outcome_unknown after dispatch instead of guessing.
      throw err;
    }
    if (res.type === "opaqueredirect" || (res.status >= 300 && res.status < 400)) {
      // Redirect refused: the request was not executed and Authorization was
      // never replayed to the redirect target.
      await discardBody(res);
      throw new JudgmentError("unavailable", "not_submitted", "safe_before_submit", "http:redirect_refused", "redirect_refused");
    }
    return res;
  }

  private async readBounded(res: Response): Promise<Uint8Array> {
    const reader = res.body?.getReader();
    if (!reader) {
      const buf = new Uint8Array(await res.arrayBuffer());
      if (buf.byteLength > this.maxOutputBytes) throw oversizeError();
      return buf;
    }
    const chunks: Uint8Array[] = [];
    let total = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > this.maxOutputBytes) {
        try {
          await reader.cancel();
        } catch {
          // cancel best effort
        }
        throw oversizeError();
      }
      chunks.push(value);
    }
    const out = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
      out.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return out;
  }
}

async function discardBody(res: Response): Promise<void> {
  try {
    await res.body?.cancel();
  } catch {
    // Content is withheld anyway.
  }
}

function decodeUtf8(bytes: Uint8Array): string {
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}

function oversizeError(): JudgmentError {
  return new JudgmentError("invalid_response", "unknown", "reconcile_first", "http:body_oversize", "response_oversize");
}

function capabilitiesStatusError(status: number): JudgmentError {
  return new JudgmentError("invalid_response", "not_submitted", "safe_before_submit", `http:${status}`, `capabilities_status_${status}`);
}

function classifyStatus(status: number): JudgmentError {
  if (status === 408) {
    return new JudgmentError("outcome_unknown", "unknown", "reconcile_first", `http:${status}`, "http_408");
  }
  if (status === 429) {
    return new JudgmentError("rate_limited", "not_submitted", "safe_before_submit", `http:${status}`, "http_429");
  }
  if (status === 401 || status === 403) {
    return new JudgmentError("unauthorized", "not_submitted", "safe_before_submit", `http:${status}`, `http_${status}`);
  }
  if (status >= 500) {
    // A 5xx (including 503) cannot prove the request was not executed.
    return new JudgmentError("unavailable", "unknown", "reconcile_first", `http:${status}`, "http_5xx");
  }
  if (status >= 400) {
    return new JudgmentError("invalid_request", "not_submitted", "safe_before_submit", `http:${status}`, "http_4xx");
  }
  return new JudgmentError("invalid_response", "unknown", "reconcile_first", `http:${status}`, `http_${status}`);
}

/** Redacted body reference helper (status + truncated digest, no content). */
export function bodyRef(status: number, body: string): string {
  const digest = createHash("sha256").update(body, "utf8").digest("hex").slice(0, 12);
  return `http:${status}:sha256:${digest}`;
}

function parseHTTPError(body: Uint8Array, status: number): JudgmentError | null {
  try {
    const text = decodeUtf8(body);
    const e = JSON.parse(text)?.error;
    if (!e || !ERROR_CODES.includes(e.code) || !SUBMISSION_STATES.includes(e.submission_state) || !RETRY_CLASSES.includes(e.retry_class)) return null;
    if (e.submission_state !== "not_submitted" && e.retry_class === "safe_before_submit") return null;
    return new JudgmentError(e.code, e.submission_state, e.retry_class, bodyRef(status, text), "adapter_error");
  } catch { return null; }
}
