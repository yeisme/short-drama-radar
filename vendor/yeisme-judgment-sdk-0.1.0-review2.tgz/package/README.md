# @yeisme/judgment-sdk (TypeScript)

独立 TS 包：`@yeisme/judgment-sdk`（拟议发布名，当前仅作本地包名；未发布到 npm）。零运行时依赖（digest 用 `node:crypto`），bun 运行时。许可证 Apache-2.0（见本目录 `LICENSE`）。

## 边界

- 与 Go 包同一合同、同一向量集、同一 verdict aggregate（`sha256:d2073de1…`，由 `test/conformance.test.ts` 对照 manifest 强制）。
- 源码零 `process.env`、零 Aigora gateway 引用（测试内扫描断言）；凭据由调用方经 `HttpTransportOptions.headers` 注入。
- 从不自动重试：一次 `evaluate` 恰好一次请求；提交后 abort/超时分类为 `outcome_unknown` + `reconcile_first`。

## 验证

```bash
bun test
```

覆盖：90 条共享 conformance 向量、spec 全部 Scenario、HTTP（`Bun.serve` 计数证明零重发）与 stdio transport（子进程单帧协议、版本握手 fail-closed）。`test/conformance.json` / `test/manifest.json` 由 `../schema/generate.py` 生成，禁止手改。

## 入口速览（`src/index.ts`）

- `parseRequest` / `parseCapabilities` / `parseResult`：严格验证，抛出带稳定 reason token 的 `ValidationError`。
- `checkCapabilities(caps, req, gateOptions)`：提交前能力门。
- `JudgmentClient`：`capabilities()`、`evaluate()`、可选 `reconcile()` / `cancel()`（仅能力声明支持时）。
- `canonicalJson` / `digest`：RFC 8785 / JCS 等价规范化。
- `FixtureTransport`：离线 fixture；`HttpTransport` / `StdioTransport`：注入 transport。
- `adoptionBlockers` / `completeAdoptionAllowed`：必需项拒答阻止完整采纳。

## 打包说明（发布前）

`package.json` 的 `exports` 指向 TS 源（bun 原生执行）；如需发布转产物，须在 owner 授权的发布 change 中加入构建步骤与 `LICENSE`、`README` 的 npm 打包核验，本仓不预先声明已发布。
