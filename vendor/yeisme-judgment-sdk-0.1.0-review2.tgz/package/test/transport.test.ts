import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, test } from "bun:test";
import { HttpTransport } from "../src/http.ts";
import { StdioTransport } from "../src/stdio.ts";
import { JudgmentClient } from "../src/client.ts";
import { JudgmentError } from "../src/errors.ts";
import { parseRequest, parseCapabilities } from "../src/validate.ts";

interface Case { id: string; value?: unknown; capabilities?: unknown; result?: unknown }
const doc = JSON.parse(readFileSync(join(import.meta.dir, "conformance.json"), "utf8")) as { cases: Case[] };
const requestFull = JSON.stringify(doc.cases.find((c) => c.id === "request-valid-full")!.value);
const resultFull = JSON.stringify(doc.cases.find((c) => c.id === "result-valid-full")!.result);
const capsFull = JSON.stringify(doc.cases.find((c) => c.id === "gate-ok-full")!.capabilities);

function startServer(handler: (req: Request) => Response | Promise<Response>): { url: string; server: ReturnType<typeof Bun.serve> } {
  const server = Bun.serve({ port: 0, fetch: handler });
  return { url: `http://${server.hostname}:${server.port}`, server };
}

describe("HTTP transport", () => {
  test("happy path with injected Authorization", async () => {
    let evaluateHits = 0;
    const { url, server } = startServer((req) => {
      if (req.headers.get("authorization") !== "Bearer test-injected") {
        return new Response("", { status: 401 });
      }
      if (req.url.endsWith("/v1/judgments/capabilities")) {
        return new Response(capsFull, { headers: { "content-type": "application/json" } });
      }
      evaluateHits++;
      return new Response(resultFull, { headers: { "content-type": "application/json" } });
    });
    try {
      const transport = new HttpTransport({ baseUrl: url, headers: () => ({ Authorization: "Bearer test-injected" }) });
      const client = new JudgmentClient(transport);
      const res = await client.evaluate(parseRequest(requestFull));
      expect(res.executionStatus).toBe("succeeded");
      expect(evaluateHits).toBe(1);
    } finally {
      server.stop(true);
    }
  });

  test("503 maps to unavailable/unknown/reconcile_first without leaking the body", async () => {
    const secretBody = "upstream exploded with internal account 42 and raw response text";
    let hits = 0;
    const { url, server } = startServer((req) => {
      if (req.url.endsWith("/v1/judgments/capabilities")) {
        return new Response(capsFull);
      }
      hits++;
      return new Response(secretBody, { status: 503 });
    });
    try {
      const client = new JudgmentClient(new HttpTransport({ baseUrl: url }));
      const err = await client.evaluate(parseRequest(requestFull)).then(() => null, (e) => e as JudgmentError);
      expect(err?.code).toBe("unavailable");
      expect(err?.submissionState).toBe("unknown");
      expect(err?.retryClass).toBe("reconcile_first");
      expect(err?.message.includes(secretBody)).toBe(false);
      expect(hits).toBe(1); // no implicit retry
    } finally {
      server.stop(true);
    }
  });

  test("redirect is refused and never re-sent with credentials", async () => {
    let redirectHits = 0;
    const { url, server } = startServer((req) => {
      if (req.url.endsWith("/v1/judgments/capabilities")) {
        return new Response(capsFull);
      }
      redirectHits++;
      return new Response("", { status: 302, headers: { location: "https://evil.example/collect" } });
    });
    try {
      const transport = new HttpTransport({
        baseUrl: url,
        headers: () => ({ Authorization: "Bearer never-forwarded" }),
      });
      const client = new JudgmentClient(transport);
      const err = await client.evaluate(parseRequest(requestFull)).then(() => null, (e) => e as JudgmentError);
      expect(err?.code).toBe("unavailable");
      expect(err?.detail).toBe("redirect_refused");
      expect(redirectHits).toBe(1);
    } finally {
      server.stop(true);
    }
  });

  test("oversize response fails closed", async () => {
    const { url, server } = startServer((req) => {
      if (req.url.endsWith("/v1/judgments/capabilities")) {
        return new Response(capsFull);
      }
      return new Response("x".repeat(4096), { status: 200 });
    });
    try {
      const transport = new HttpTransport({ baseUrl: url, maxOutputBytes: 128 });
      const client = new JudgmentClient(transport);
      const err = await client.evaluate(parseRequest(requestFull)).then(() => null, (e) => e as JudgmentError);
      expect(err?.code).toBe("invalid_response");
      expect(err?.detail).toBe("response_oversize");
    } finally {
      server.stop(true);
    }
  });

  test("post-submit timeout is outcome_unknown with zero re-send", async () => {
    let hits = 0;
    const { url, server } = startServer((req) => {
      if (req.url.endsWith("/v1/judgments/capabilities")) {
        return new Response(capsFull);
      }
      hits++;
      return new Promise<Response>((resolve) => {
        setTimeout(() => resolve(new Response(resultFull)), 500);
      });
    });
    try {
      const client = new JudgmentClient(new HttpTransport({ baseUrl: url }));
      const tree = JSON.parse(requestFull);
      tree.limits.deadline_ms = 120;
      const err = await client.evaluate(parseRequest(JSON.stringify(tree))).then(() => null, (e) => e as JudgmentError);
      expect(err?.code).toBe("outcome_unknown");
      expect(err?.submissionState).toBe("unknown");
      expect(err?.retryClass).toBe("reconcile_first");
      expect(hits).toBe(1);
    } finally {
      server.stop(true);
    }
  });
});

describe("stdio transport", () => {
  const build = (mode: string, maxLineBytes?: number): StdioTransport =>
    new StdioTransport({
      argv: [process.execPath, join(import.meta.dir, "stdio-helper.ts")],
      env: { ...process.env, JUDGMENT_STDIO_CHILD: mode },
      maxLineBytes,
    });

  test("serve capabilities and evaluate", async () => {
    const client = new JudgmentClient(build("serve"));
    const caps = await client.capabilities();
    expect(caps.contractVersion).toBe("1.0");
    const res = await client.evaluate(parseRequest(requestFull));
    expect(res.executionStatus).toBe("succeeded");
  });

  test("error envelope is classified verbatim", async () => {
    const transport = build("error-envelope");
    const err = await transport.capabilities().then(() => null, (e) => e as JudgmentError);
    expect(err?.code).toBe("outcome_unknown");
    expect(err?.retryClass).toBe("reconcile_first");
    expect(err?.diagnosticRef).toBe("stdio-test");
  });

  test("version handshake mismatch fails closed", async () => {
    const transport = build("version-mismatch");
    const err = await transport.capabilities().then(() => null, (e) => e as JudgmentError);
    expect(err?.code).toBe("invalid_response");
    expect(err?.detail).toBe("stdio_version_mismatch");
  });

  test("oversize frame fails closed", async () => {
    const transport = build("oversize", 128);
    const err = await transport.capabilities().then(() => null, (e) => e as JudgmentError);
    expect(err?.code).toBe("invalid_response");
    expect(err?.detail).toBe("stdio_frame_oversize");
  });

  test("garbage frame fails closed", async () => {
    const transport = build("garbage");
    const err = await transport.capabilities().then(() => null, (e) => e as JudgmentError);
    expect(err?.code).toBe("invalid_response");
  });

  test("empty argv is rejected", () => {
    expect(() => new StdioTransport({ argv: [] })).toThrow();
  });
});

test("parseCapabilities still validates after transport round trip", () => {
  const caps = parseCapabilities(capsFull);
  expect(caps.primitives).toContain("binary");
});

test("HTTP errors preserve validated enums but never diagnostic text", async () => {
  for (const [code, submission_state, retry_class, status] of [
    ["unsupported_capability", "not_submitted", "never", 400],
    ["outcome_unknown", "submitted", "reconcile_first", 408],
    ["unavailable", "not_submitted", "safe_before_submit", 503],
  ] as const) {
    let calls = 0;
    const {url, server} = startServer(() => {
      calls++;
      return Response.json({error: {code, submission_state, retry_class, detail:"sensitive-text", diagnostic_ref:"sensitive-text"}}, {status});
    });
    try {
      const transport = new HttpTransport({baseUrl:url});
      try {await transport.evaluate(parseRequest(requestFull)); throw new Error("expected rejection");}
      catch (error) {
        expect(error).toBeInstanceOf(JudgmentError);
        const e = error as JudgmentError;
        expect([e.code,e.submissionState,e.retryClass]).toEqual([code,submission_state,retry_class]);
        expect(e.message+e.diagnosticRef).not.toContain("sensitive-text");
      }
      expect(calls).toBe(1);
    } finally {server.stop(true);}
  }
});
