import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, test } from "bun:test";
import { canonicalJson, digest, marshalTree, parseTree } from "../src/canonical.ts";
import { ValidationError } from "../src/errors.ts";
import {
  checkCapabilities,
  parseCapabilities,
  parseRequest,
  parseResult,
  type GateOptions,
  type RequestOptions,
} from "../src/validate.ts";
import { defaultPrecisionPolicy } from "../src/types.ts";

interface VectorCase {
  id: string;
  kind: string;
  value?: unknown;
  value_a?: unknown;
  value_b?: unknown;
  expected_digest?: string;
  text?: string;
  expect?: string;
  reason?: string;
  capabilities?: unknown;
  request?: unknown;
  result?: unknown;
  options?: {
    require_verified_underlying_revision?: boolean;
    require_probability?: boolean;
    known_extensions?: string[];
  };
  policy?: { version: string; abs_sum_tolerance: number };
}

interface ConformanceDoc {
  case_count: number;
  expected_verdict_aggregate: string;
  cases: VectorCase[];
}

interface ManifestDoc {
  conformance_case_count: number;
  expected_verdict_aggregate: string;
  files: Record<string, { sha256: string; bytes: number }>;
}

const doc = JSON.parse(readFileSync(join(import.meta.dir, "conformance.json"), "utf8")) as ConformanceDoc;
const manifest = JSON.parse(readFileSync(join(import.meta.dir, "manifest.json"), "utf8")) as ManifestDoc;

function sha256Hex(data: string | Uint8Array): string {
  return createHash("sha256").update(data).digest("hex");
}

test("local vectors share the canonical generated source", () => {
  const local = readFileSync(join(import.meta.dir, "conformance.json"));
  const localDigest = sha256Hex(local);
  expect(manifest.files["typescript/test/conformance.json"]).toBeDefined();
  expect(manifest.files["typescript/test/conformance.json"].sha256).toBe(localDigest);
  expect(manifest.files["typescript/test/conformance.json"].bytes).toBe(local.byteLength);
  expect(manifest.files["schema/vectors/conformance.json"].sha256).toBe(localDigest);
});

function expectedVerdict(c: VectorCase): string {
  if (c.kind === "digest" || c.kind === "digest_variants") {
    return c.expected_digest as string;
  }
  if (c.kind === "digest_nonfinite") return "error";
  if (c.expect === "valid" || c.expect === "ok") return c.expect as string;
  if (c.expect === "invalid") return `invalid:${c.reason}`;
  return `unsupported:${c.reason}`;
}

function runCase(c: VectorCase): string {
  switch (c.kind) {
    case "digest":
      return digest(c.value as never);
    case "digest_variants": {
      const a = digest(c.value_a as never);
      const b = digest(c.value_b as never);
      if (a !== b) return `variant_divergence:${a}/${b}`;
      return a;
    }
    case "digest_nonfinite": {
      try {
        const tree = parseTree(c.text as string);
        canonicalJson(tree);
        return "no_error";
      } catch {
        return "error";
      }
    }
    case "request_validate": {
      const known = c.options?.known_extensions ?? [];
      try {
        parseRequest(marshalTree(c.value as never), { knownExtensions: known });
        return "valid";
      } catch (err) {
        if (err instanceof ValidationError) return `invalid:${err.reason}`;
        return "error:unexpected";
      }
    }
    case "capability_gate": {
      const caps = parseCapabilities(marshalTree(c.capabilities as never));
      const known = c.options?.known_extensions ?? [];
      const gate: GateOptions = {
        requireVerifiedUnderlyingRevision: c.options?.require_verified_underlying_revision ?? false,
        requireProbability: c.options?.require_probability ?? false,
      };
      const requestOpts: RequestOptions = { knownExtensions: known };
      const req = parseRequest(marshalTree(c.request as never), requestOpts);
      try {
        checkCapabilities(caps, req, gate);
        return "ok";
      } catch (err) {
        if (err instanceof ValidationError) return `unsupported:${err.reason}`;
        return "error:unexpected";
      }
    }
    case "result_validate": {
      const req = parseRequest(marshalTree(c.request as never));
      const policy = c.policy
        ? { version: c.policy.version, absSumTolerance: c.policy.abs_sum_tolerance }
        : defaultPrecisionPolicy();
      try {
        parseResult(marshalTree(c.result as never), req, policy);
        return "valid";
      } catch (err) {
        if (err instanceof ValidationError) return `invalid:${err.reason}`;
        return "error:unexpected";
      }
    }
  }
  return "error:unknown_kind";
}

describe("shared conformance vectors", () => {
  test("non-empty vector set", () => {
    expect(doc.case_count).toBeGreaterThan(20);
    expect(doc.cases.length).toBe(doc.case_count);
  });

  for (const c of doc.cases) {
    test(`vector ${c.id}`, () => {
      expect(runCase(c)).toBe(expectedVerdict(c));
    });
  }

  test("verdict aggregate matches the generated expectation", () => {
    const lines = doc.cases.map((c) => `${c.id}\t${runCase(c)}`);
    const aggregate = "sha256:" + sha256Hex(lines.join("\n"));
    expect(aggregate).toBe(doc.expected_verdict_aggregate);
    expect(aggregate).toBe(manifest.expected_verdict_aggregate);
  });
});

test("product source stays credential- and gateway-free", () => {
  const dir = join(import.meta.dir, "..", "src");
  const entries = [...new Bun.Glob("*.ts").scanSync(dir)];
  expect(entries.length).toBeGreaterThan(0);
  for (const name of entries) {
    const src = readFileSync(join(dir, name), "utf8");
    expect(src.includes("process.env")).toBe(false);
    expect(src.includes("yeisme/aigora")).toBe(false);
  }
});
