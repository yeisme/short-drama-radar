import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, test } from "bun:test";
import { FixtureTransport } from "../src/transport.ts";
import { JudgmentClient } from "../src/client.ts";
import { JudgmentError } from "../src/errors.ts";
import { adoptionBlockers, completeAdoptionAllowed } from "../src/adoption.ts";
import { parseCapabilities, parseRequest, parseResult, checkCapabilities } from "../src/validate.ts";
import { defaultPrecisionPolicy } from "../src/types.ts";

interface Case { id: string; kind: string; value?: unknown; capabilities?: unknown; request?: unknown; result?: unknown }
const doc = JSON.parse(readFileSync(join(import.meta.dir, "conformance.json"), "utf8")) as { cases: Case[] };

function vector(id: string): Case {
  const found = doc.cases.find((c) => c.id === id);
  if (!found) throw new Error(`vector ${id} missing`);
  return found;
}

const requestFull = JSON.stringify(vector("request-valid-full").value);
const resultFull = JSON.stringify(vector("result-valid-full").result);
const capsFull = JSON.stringify(vector("gate-ok-full").capabilities);

function buildRequest(deadlineMs?: number): ReturnType<typeof parseRequest> {
  const tree = JSON.parse(requestFull);
  if (deadlineMs !== undefined) {
    (tree.limits as Record<string, unknown>).deadline_ms = deadlineMs;
  }
  return parseRequest(JSON.stringify(tree));
}

test("scenario: offline consumer validates request and result without network", () => {
  const caps = parseCapabilities(capsFull);
  const req = parseRequest(requestFull);
  const result = parseResult(resultFull, req, defaultPrecisionPolicy());
  const fixture = new FixtureTransport(caps, async () => result);
  const client = new JudgmentClient(fixture);
  const parsed = client.evaluate(req);
  expect(parsed).resolves.toMatchObject({ executionStatus: "succeeded" });
  expect(fixture.capabilitiesCalls).toBe(1);
  expect(fixture.evaluateCalls).toBe(1);
});

test("scenario: unsupported primitive is rejected before submit", async () => {
  const caps = parseCapabilities(capsFull);
  caps.primitives = ["choice", "ordinal_score"]; // binary removed
  const fixture = new FixtureTransport(caps, async () => {
    throw new Error("must not be called");
  });
  const client = new JudgmentClient(fixture);
  const err = await client.evaluate(parseRequest(requestFull)).then(
    () => null,
    (e) => e as JudgmentError,
  );
  expect(err).toBeInstanceOf(JudgmentError);
  expect(err?.code).toBe("unsupported_capability");
  expect(err?.submissionState).toBe("not_submitted");
  expect(err?.retryClass).toBe("never");
  expect(err?.detail).toBe("primitive_unsupported");
  expect(fixture.evaluateCalls).toBe(0);
});

test("scenario: reordered items align by (candidate_id, question_id)", () => {
  const req = parseRequest(requestFull);
  const tree = JSON.parse(resultFull);
  tree.items = tree.items.reverse();
  const res = parseResult(JSON.stringify(tree), req, defaultPrecisionPolicy());
  for (const [cid, qid] of req.expectedPairs()) {
    const item = res.itemByPair(cid, qid);
    expect(item).not.toBeNull();
    expect(item?.answerStatus).toBeTruthy();
  }
});

test("scenario: missing pair is a protocol error, never a patch", () => {
  const req = parseRequest(requestFull);
  const tree = JSON.parse(resultFull);
  tree.items = tree.items.filter(
    (i: { candidate_id: string; question_id: string }) => !(i.candidate_id === "c-alt" && i.question_id === "q-intensity"),
  );
  let reason = "";
  try {
    parseResult(JSON.stringify(tree), req, defaultPrecisionPolicy());
  } catch (e) {
    reason = (e as { reason: string }).reason;
  }
  expect(reason).toBe("items_missing");
});

test("scenario: confidence and probability_true stay null without calibration", () => {
  const req = parseRequest(requestFull);
  const res = parseResult(resultFull, req, defaultPrecisionPolicy());
  const item = res.itemByPair("c-open", "q-tone");
  expect(item?.confidence).toBeNull();
  expect(item?.probabilityTrue).toBeNull();
  const caps = parseCapabilities(capsFull);
  let reason = "";
  try {
    checkCapabilities(caps, req, { requireConfidence: true });
  } catch (e) {
    reason = (e as { reason: string }).reason;
  }
  expect(reason).toBe("confidence_required");
});

test("scenario: required abstention blocks complete adoption", () => {
  const req = parseRequest(requestFull);
  const tree = JSON.parse(resultFull);
  const first = tree.items[0];
  first.answer_status = "abstained";
  first.value = null;
  first.distribution = null;
  const res = parseResult(JSON.stringify(tree), req, defaultPrecisionPolicy());
  expect(completeAdoptionAllowed(req, res)).toBe(false);
  expect(adoptionBlockers(req, res)).toEqual([
    { candidateId: "c-open", questionId: "q-tone", answerStatus: "abstained", problem: "abstained" },
  ]);
});

test("scenario: timeout after submit reports outcome_unknown without resend", async () => {
  const caps = parseCapabilities(capsFull);
  const fixture = new FixtureTransport(caps, async (_req, signal) => {
    return await new Promise<never>((_resolve, reject) => {
      const onAbort = () => reject(signal?.reason ?? new Error("aborted"));
      if (signal?.aborted) onAbort();
      signal?.addEventListener("abort", onAbort);
    });
  });
  const client = new JudgmentClient(fixture);
  const err = await client.evaluate(buildRequest(100)).then(
    () => null,
    (e) => e as JudgmentError,
  );
  expect(err).toBeInstanceOf(JudgmentError);
  expect(err?.code).toBe("outcome_unknown");
  expect(err?.submissionState).toBe("unknown");
  expect(err?.retryClass).toBe("reconcile_first");
  expect(fixture.evaluateCalls).toBe(1); // zero automatic re-sends
});

test("scenario: historical replay performs zero provider calls", () => {
  const caps = parseCapabilities(capsFull);
  const fixture = new FixtureTransport(caps, async () => {
    throw new Error("replay must not reach the provider");
  });
  const req = parseRequest(requestFull);
  const replayed = parseResult(resultFull, req, defaultPrecisionPolicy());
  expect(replayed.resolvedModel.requestedModel).toBe(req.model.requestedModel);
  expect(replayed.inputDigest).toBe(req.inputDigest());
  expect(fixture.evaluateCalls).toBe(0);
  expect(fixture.capabilitiesCalls).toBe(0);
});

test("scenario: unknown required extension is refused", () => {
  const tree = JSON.parse(requestFull);
  tree.extensions = [{ name: "x_future_v2", required: true, payload: {} }];
  let reason = "";
  try {
    parseRequest(JSON.stringify(tree));
  } catch (e) {
    reason = (e as { reason: string }).reason;
  }
  expect(reason).toBe("unknown_required_extension");
});

test("scenario: versioned normalization covers provider/derived divergence", () => {
  const req = parseRequest(requestFull);
  const without = JSON.parse(resultFull);
  for (const item of without.items) {
    if (item.question_id === "q-intensity" && item.candidate_id === "c-open") {
      delete item.normalization;
    }
  }
  let reason = "";
  try {
    parseResult(JSON.stringify(without), req, defaultPrecisionPolicy());
  } catch (e) {
    reason = (e as { reason: string }).reason;
  }
  expect(reason).toBe("normalization_missing");
  expect(() => parseResult(resultFull, req, defaultPrecisionPolicy())).not.toThrow();
});

test("scenario: router model identity is preserved, not rewritten", () => {
  const req = parseRequest(requestFull);
  const res = parseResult(resultFull, req, defaultPrecisionPolicy());
  expect(res.resolvedModel.underlyingRevision).toBeNull();
  expect(res.resolvedModel.underlyingRevisionVerified).toBe(false);
  expect(res.resolvedModel.requestedModel).toBe("typesafe/jev-1.13");
  expect(res.resolvedModel.pinLevel).toBe("router_model_id");
  expect(res.resolvedModel.responseModel).toBe("jev-1.13.0");
  const caps = parseCapabilities(capsFull);
  let reason = "";
  try {
    checkCapabilities(caps, req, { requireVerifiedUnderlyingRevision: true });
  } catch (e) {
    reason = (e as { reason: string }).reason;
  }
  expect(reason).toBe("underlying_revision_required");
});

describe("optional extensions require declared capability", () => {
  test("reconcile and cancel are refused without capability", async () => {
    const caps = parseCapabilities(capsFull);
    const fixture = new FixtureTransport(caps, async () => {
      throw new Error("unused");
    });
    const client = new JudgmentClient(fixture);
    const reconcileErr = await client.reconcile("att-0001").then(
      () => null,
      (e) => e as JudgmentError,
    );
    expect(reconcileErr?.code).toBe("unsupported_capability");
    const cancelErr = await client.cancel("att-0001").then(
      () => null,
      (e) => e as JudgmentError,
    );
    expect(cancelErr?.code).toBe("unsupported_capability");
  });
});
