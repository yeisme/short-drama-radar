/**
 * stdio child helper for StdioTransport tests. Mode comes from the
 * JUDGMENT_STDIO_CHILD env; the protocol is one JSON envelope per direction.
 */
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const mode = process.env.JUDGMENT_STDIO_CHILD ?? "serve";

let input = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk: string) => {
  input += chunk;
});
process.stdin.on("end", () => {
  let frame: { kind?: string };
  try {
    frame = JSON.parse(input.trim().split("\n")[0] ?? "{}");
  } catch {
    process.stderr.write("child: bad frame");
    process.exit(3);
  }
  const conformancePath = join(dirname(fileURLToPath(import.meta.url)), "conformance.json");
  const conformance = JSON.parse(readFileSync(conformancePath, "utf8")) as {
    cases: Array<{ id: string; capabilities?: unknown; result?: unknown }>;
  };
  const caps = conformance.cases.find((c) => c.id === "gate-ok-full")?.capabilities ?? {};
  const result = conformance.cases.find((c) => c.id === "result-valid-full")?.result ?? {};
  const write = (schemaVersion: string, ok: boolean, payload: unknown): void => {
    process.stdout.write(JSON.stringify({ schema_version: schemaVersion, ok, payload }) + "\n");
  };
  switch (mode) {
    case "serve":
      write("1.0", true, frame.kind === "capabilities" ? caps : result);
      break;
    case "error-envelope":
      write("1.0", false, {
        error: {
          code: "outcome_unknown",
          submission_state: "unknown",
          retry_class: "reconcile_first",
          diagnostic_ref: "stdio-test",
        },
      });
      break;
    case "version-mismatch":
      write("2.0", true, caps);
      break;
    case "oversize":
      process.stdout.write("x".repeat(300) + "\n");
      break;
    case "garbage":
      process.stdout.write("not-json\n");
      break;
    default:
      process.exit(9);
  }
});
